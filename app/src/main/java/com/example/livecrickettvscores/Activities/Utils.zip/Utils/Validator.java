package com.example.livecrickettvscores.Activities.Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {


    public static Boolean isValidEmail(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }


    public static Boolean doesItHaveSpecialCharacter(String val) {
        Pattern pattern;
        Matcher matcher;
        final String _PATTERN = "[a-zA-Z. ]*";
        pattern = Pattern.compile(_PATTERN);
        matcher = pattern.matcher(val);
        return matcher.matches();

    }
}