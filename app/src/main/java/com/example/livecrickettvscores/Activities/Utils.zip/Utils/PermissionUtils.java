package com.example.livecrickettvscores.Activities.Utils;

import android.Manifest;
import android.app.Activity;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.normal.TedPermission;

import java.util.List;

public class PermissionUtils {

    private static OnPermissionSuccessListener onPermissionSuccessListener;

    public static void AsKPermissionationSplashScreen(final Activity activity, PermissionListener permissionListener) {

        TedPermission.create().setPermissions(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION).setRationaleMessage(ConstantsMessages.PermissionRequiredMsg).setRationaleConfirmText("OK").setDeniedMessage(ConstantsMessages.PermissionRejectedMsg).setPermissionListener(permissionListener).check();
    }
    public static void AsKPermissionForCamera(final Activity activity, final OnPermissionSuccessListener permissionListener) {
        TedPermission.create().setPermissions(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE).setRationaleMessage("We need your permission to open Camera in your Device.").setRationaleConfirmText("OK").setDeniedMessage(ConstantsMessages.PermissionRejectedMsg).setPermissionListener(new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                if (permissionListener != null) {
                    permissionListener.onPermissionGranted();
                }
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Global.showCustomStaticToast(activity, ConstantsMessages.PermissionDenied + deniedPermissions.toString());
            }
        }).check();
    }

    public static void AsKPermissionForLocation(final Activity activity, final OnPermissionSuccessListener permissionListener) {
        TedPermission.create().setPermissions(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION).setRationaleMessage("We need your permission to access your location on your Device.").setRationaleConfirmText("OK").setDeniedMessage(ConstantsMessages.PermissionRejectedMsg).setPermissionListener(new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                if (permissionListener != null) {
                    permissionListener.onPermissionGranted();
                }
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Global.showCustomStaticToast(activity, ConstantsMessages.PermissionDenied + deniedPermissions.toString());
            }
        }).check();
    }

    public static void AsKPermissionForCameraAndVideo(final Activity activity, final OnPermissionSuccessListener permissionListener) {
        TedPermission.create().setPermissions(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE).setRationaleMessage("We need permission to access and capture images or video from your device for uploading.").setRationaleConfirmText("OK").setDeniedMessage(ConstantsMessages.PermissionRejectedMsg).setPermissionListener(new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                if (permissionListener != null) {
                    permissionListener.onPermissionGranted();
                }
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Global.showCustomStaticToast(activity, ConstantsMessages.PermissionDenied + deniedPermissions.toString());
            }
        }).check();
    }


    public void setOnPermissionSuccessListener(OnPermissionSuccessListener onPermissionSuccessListener) {
        this.onPermissionSuccessListener = onPermissionSuccessListener;
    }

    public interface OnPermissionSuccessListener {
        void onPermissionGranted();
    }
}
